print("Login kiriting:👉")
login = input()
print("Parol kiriting:👉")
parol = input()

if login == "og'abek" and parol == "0808":
    print("Qaysi foydalanuvchi haqida ma'lumot kerak?")
    print("Bizda mavjud ismlar: sarvar, ali, laylo, og'abek,zuhriddin,nursulton,gavhar.")
    ism = ""
    while ism != "stop":
        print("Ism kiriting (yoki 'stop'):")
        ism = input()
        if ism == "sarvar":
           print("Sarvar - Dasturchi, Python bo'yicha tajribaga ega.")
        elif ism == "ali":
           print("Ali - Web dizayner, Figma va Adobe bilan ishlaydi.")
        elif ism == "laylo":
           print("Laylo - Backend dasturchi, Django va FastAPI bilan ishlaydi.")
        elif ism == "og'abek":
          print("Og'abek - IT dasturchi, Python boyicha tajribasi bor. ")
        elif ism == "zuhriddin":
          print("Zuhriddin - Dasturchi,HTML boyicha tajribasi bor. ")
        elif ism == "nursulton":
           print("Nursulton - Dasturchi,C++ boyicha tajribasi bor. ")
        elif ism == "gavhar":
           print("Gavhar - Dasturchi,JAVA boyicha tajribasi bor.")
        elif ism == "stop":
          print("Dastur toxtadi ❌.")
        else:
          print("Ma'lumot topilmadi 🤷‍♂️.")
else:
  print("Login yoki parol notogri 🔐.")