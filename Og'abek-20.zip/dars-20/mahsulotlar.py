mahsulotlar = {
    "non": 3500,
    "sut ": 9000,
    "tuxum ": 12000,
    "go'sht": 80000,
    "kartoshka": 6000,
    "piyoz": 5000,
    "sabzi": 4500,
    "guruch": 15000,
    "un": 7000,
    "shakar": 9000,
    "yog'": 22000,
    "makaron": 7000,
    "choy": 11000,
    "qahva": 15000,
    "banan": 18000,
    "olma": 12000,
    "apelsin": 16000,
    "limon": 14000,
    "bodring": 8000,
    "pomidor": 10000,
    "qovun": 7000,
    "tarvuz": 4000,
    "bodom": 85000,
    "yong'oq": 75000,
    "tuxum": 1200,
    "kolbasa": 25000,
    "sosiska": 22000,
    "sir (pishloq,": 50000,
    "kefir": 10000,
    "smatana": 12000,
    "yogurt": 8000,
    "ketchup": 11000,
    "mayonez": 10000,
    "konserva baliq": 16000,
    "qora non": 3000,
    "buterbrod non": 6000,
    "shokolad": 9000,
    "konfet": 20000,
    "pechenye": 17000,
    "asal": 60000,
    "yeryong'oq": 20000,
    "suv ": 3000,
    "gazli suv": 5000,
    "limonad": 7000,
    "energiya ichimligi": 12000,
    "tuxumli nonushta to'plami": 18000,
    "muzqaymoq": 6000,
    "qatiq": 8000,
    "lavash": 10000,
    "shaurma": 18000,
}














































