from mahsulotlar import mahsulotlar

def buyurtma_ber():
    narxlar =[]
    ishora = True
    while ishora:
        mahsulot_nomi = input("Mahsulot nomini kiriting: ").lower().strip()

        if mahsulot_nomi in mahsulotlar:
          narx = mahsulotlar[mahsulot_nomi]
          narxlar.append(narx)
          print(f"{mahsulot_nomi.capitalize()} narx: {narx} so'm")
        else:
            print(f"Bunday mahsulot yo'q")

        javob = input(f"Yana mahsulot tanlaysizmi? (ha yoki yo'q): ").lower()
        if javob == "yo'q" or javob =="no":
             ishora = False
        elif javob == "ha" or javob == "yes":
             continue
        else:
            ishora = False
    jami_summa = sum(narxlar)
    print(f"\nSiz uchun to'lov miqdori: {jami_summa()} so'm\n")























