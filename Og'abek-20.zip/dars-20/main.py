from kutubxona import buyurtma_ber
buyurtma_ber()






