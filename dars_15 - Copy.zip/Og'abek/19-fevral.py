# menu = ['osh','somsa','honim','shashlik']
# buyurtmalar = []
# narx = 0
# x = int(input("Hurmatli mijoz,nechta taom buyurasiz:\t"))
# for i in range(0,x):
#     buyurtma = input(f"{i+1}-buyurtmani kiriting:\t")
#     buyurtmalar.append(buyurtma)


# if  buyurtmalar:
#     for taom in buyurtmalar:
#         if taom in menu:
#             print(f"\nSizning{taom.title()} nomli buyurtmangiz qabul qilindi!")
#         else:
#             print(f"\nSizning{taom.title()} nomli buyurtmangiz mavjud emas!")
    
# else:
#     print("Savatchangiz bo'sh!")
# for a in buyurtmalar:
#     if a == "osh":
#          narx += 10_000
#     if a == "somsa":
#        narx += 15_000
#     if a == "honim":
#        narx += 20_000
#     if a == "shashlik":
#        narx += 25_000
# print(f"\nSizning buyurtmalar soningiz: {len(buyurtmalar)}")
# print(f"Sizning to'lovingiz: {narx}")


# 15-dars 1-topshiriq

# ismlar = []
# ishora = True
# n = 1
# while ishora:
#     ism = input(f"{n}-Ismni kiriting:")
#     n = 1+ n
#     ismlar.append(ism)
#     if ism.lower() == "stop":
#        ishora = False
#        print


# talabalar = ["Ozodbek","Og'abek","Nursulton","Gavxar","G'olibbek","Og'abek"]
# n = 0
# baxolar = {}
# while n< len(talabalar):
#     talaba = talabalar[n]
#     n = 1 + n
#     baxo =int(input(f"{talaba}ning baxosini kiriting:"))
#     baxolar[talaba] = baxo

# print("\nTalabalar baxosi:")
# for i,b in baxolar.items():
#     print(f"{i}ning baxosi: {b}")


# def ajrat_soz(soz):
#     unli = "a,o,u,e,i,,A,O,U,E,I,O"
#     unli_harf=""
#     undosh_harf=""

#     for harf in soz:
#         if harf in unli:
#             unli_harf += harf
#         else:
#             undosh_harf += harf
#     return unli_harf, undosh_harf
# soz = input("So'z kiriting:")
# unli, undosh = ajrat_soz(soz)
# print(f"Unli harflar:{unli}")
# print(f"Undosh harflar:{undosh}")

# ishora=True
# while ishora:
#     h=int(input("Tana haroratini kiriting: "))
#     if h ==0:
#         ishora =False
#         print("Dastur to'xtadi")
#         break
#     if h <=30:
#        print("Sizda isitma yo'q")
#     elif 30 < h < 38:
#         print("Sizda biroz isitma bor")
#     else:
#         print("Isitma juda yuqori.Shifokorga borishingiz kerak")
    

# s=int(input("10 dan katta son kititing:" ))
# k=s**2
# print(k)






































