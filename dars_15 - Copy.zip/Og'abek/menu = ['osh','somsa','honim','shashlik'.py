# # 1-masala
# ishora = True
# while ishora:
#     yosh = int(input("Yoshingizni kiriting:(dasturni to'xtashi uchun 0 kiriting): "))
#     if yosh >= 18:
#         print("xush kelibsiz!")
#     elif yosh <= 18 and yosh > 0:
#         print("Hali yosh ekansiz:") 
#     elif yosh == 0:
#         print("dastur to'xtatildi")
#         ishora = False

        
# warehouse={"olma":50,"banan":20,"apelsin":30}
# mevalar=input("meva nomi:")

# meva=input("qancha meva olasiz:")

# print(f"ombor bo'sh.")



# talabalar = ["Ozodbek","Og'abek","Nursulton","Gavxar","G'olibbek","Ogabek"]
# n =0
# baxolar ={}
# while n< len(talabalar):
#     talaba = talabalar[n]
#     n =1 + n
#     baxo =int(input(f"{talaba}ning baxosini kiriting:"))
#     baxolar[talaba]=baxo

# print("\nTalabalar baxosi:")
# for i,b in baxolar.items():
#    print(f"{i}ning baxosi: {b}")


# 15-dars amaliy 1-topshiriq


# sonlar = []
# a=int(input("birinchi soni kiriting >>> "))
# b=int(input("ikkinchi soni kiriting >>> "))
# for son in range (+1):
#  c=a+b
#  h=
# print(f"yig'indisi:{c},{h}")

# 15-dars amaliy 3-topshiriq

# ishora=True
# while ishora:
#     r=int(input("Son kiriting:"))
#     if r ==:
#         print("Bu juft son ")
#     elif r % 2 !=0: 
#         print("Bu toq son")
#     elif r==0 or r =="stop":
#         ishora
#         print("Nolga teng")







# 1-topshiriq 

# Input: {"salom hello salom dunyo hello"}
# Output:{'salom': 2, 'hello': 2, 'dunyo': 1}


# 15-dars amaliy 5-topshiriq

# a=int(input("Son kiriting:"))
# f=[0,1]
# for i in range(2,a):
#     f.append(f[-1]+f[-2])
# print(f[:a])

#  1-topshiriq 

# Input: {"salom hello salom dunyo hello"}
# Output:{'salom': 2, 'hello': 2, 'dunyo': 1}



# 0-54 → "Sizning bahoyingiz: 2"
# 55-69 → "Sizning bahoyingiz: 3"
# 70-84 → "Sizning bahoyingiz: 4"
# 85-100 → "Sizning bahoyingiz: 5"
# Xato son kiritilsa → "Noto‘g‘ri qiymat!"


# 3-topshiriq
# bal = int(input("Balni kiriting:"))
# if bal == 0 or bal<=54:
#     print("Sizning bahoyingiz:2")
# elif bal ==55 or bal<=69:
#     print("Sizning bahoyingiz:3")
# elif bal ==70 or bal<=84:
#      print("Sizning bahoyingiz:4")
# elif bal == 85 or bal<=100:
#      print("Sizning bahoyingiz:5")
# else:
#       print("Noto'g'ri qiymat!")


# 4-topshiriq
# h = int(input("Haroratni kiriting>>>"))
# if h<0:
#     print("Juda sovuq! Issiq kiyining!")
# elif h==0 or h<=15:
#     print("Salqin havo, kurtka kiying!!")
# elif h==16 or h<=25:
#      print("Ob-havo yaxshi, yengil kiyinishingiz mumkin!")
# elif h==26 or h<=26:
#     print("Juda issiq! Ko'proq suv iching!")


# 5-topshiriq 
# k = int(input("Masofani kiriting (km)>>>"))
# if k<=5:
#     print("5000 so'm")
# elif k==6 or k<=15:
#     print("10000 so'm")
# elif k==16 or k<=30:
#     print("20000 so'm")
# elif k>31:
#     print("30000 so'm")

# 6-topshiriq
# grades = {"Ali": 85, "Vali": 92, "Zarina": 78, "Olim": 90, "Madina": 95}
# print("Eng yuqori baho",{max(grades.values())})
# print("Eng pas baho",{min(grades.values())})

# 7-topshiriq
# grades = {"Ali": 85, "Vali": 92, "Zarina": 78, "Olim": 90, "Madina": 95}
# print({sum(grades.values())/len(grades.values())})


# 8-topshiriq

# students = {
# "Ali": {"Math": 90, "English": 85, "Science": 88},
# "Vali": {"Math": 75, "English": 80, "Science": 78},
# "Zarina": {"Math": 95, "English": 92, "Science": 89}
# }



# 9-topshiriq
# dict1 = {"a": 10, "b": 20, "c": 30}
# dict2 = {"b": 5, "c": 15, "d": 25}


# 10-topshiriq
# Input: "Python dasturlash tilini o'rganish juda qiziqarli"
# Output: "dasturlash"


# 1-topshiriq

# def toliq_ism_yasa(ism,famila,tugilgan_yilingiz,tugilgan_joyingiz,email_manzilingiz,telifon_raqamingiz):
# toliq_ism =f"{ism}{famila}{tugilgan yilingiz}{tugilgan joyingiz}{email manzilingiz}{telifon raqamingiz}"

#  ism = int(input(f"Ismingizni kiriting>>>\t"))


# def get_user_info(ism, familiya, tugilgan_yil, tugilgan_joy, email=None, tel=None):
#     user_info = {}
#     user_info['ism'] = ism
#     user_info['familiya'] = familiya
#     user_info['tugilgan_yil'] = tugilgan_yil
#     user_info['tugilgan_joy'] = tugilgan_joy
#     user_info['yosh'] = 2025 - tugilgan_yil
    
#     if email:
#         user_info['email'] = email
        
#     if tel:
#         user_info['tel'] = tel
        
#     return user_info

# get_user_info = get_user_info('Hasan', 'Alimov', 1995, 'Farg\'ona', 'hsnalimov@mail.ru', '+99897123456')
# for ism, qiymat in get_user_info.items():
#     print(f"Ismi: {get_user_info['ism']}\n\
#     Familiyasi: {get_user_info['familiya']}\n\
#     Tug'ilgan yili: {get_user_info['tugilgan_yil']}\n\
#     Tug'ilgan joyi: {get_user_info['tugilgan_joy']}\n\
#     Yoshi: {get_user_info['yosh']}\n\
#     Email: {get_user_info['email']}\n\
#     Phone: {get_user_info['tel']}\n")




# def get_user_info(ism, familiya, tugilgan_yil, tugilgan_joy, email=None, tel=None):
#     user_info = {
#         'ism': ism,
#         'familiya': familiya,
#         'tugilgan_yil': tugilgan_yil,
#         'tugilgan_joy': tugilgan_joy,
#         'yosh': 2025 - tugilgan_yil
#     }
    
#     if email:
#         user_info['email'] = email
        
#     if tel:
#         user_info['tel'] = tel
        
#     return user_info

# user_info = get_user_info('Hasan', 'Alimov', 1995, "Farg'ona", 'hsnalimov@mail.ru', '+99897123456')

# # To'g'ri chop etish
# print(f"Ismi: {user_info['ism']}")
# print(f"Familiyasi: {user_info['familiya']}")
# print(f"Tug'ilgan yili: {user_info['tugilgan_yil']}")
# print(f"Tug'ilgan joyi: {user_info['tugilgan_joy']}")
# print(f"Yoshi: {user_info['yosh']}")
# if 'email' in user_info:
#     print(f"Email: {user_info['email']}")
# if 'tel' in user_info:
#     print(f"Telefon: {user_info['tel']}")


# 2-topshiriq

# import random


# tasodifiy_son=random.randint(1,100)
# while True:
#     try:
#         tahmin=int(input("1 dan 100 gacha bo'lgan tasodifiy son kiriting>>>"))
#         if tahmin>=tasodifiy_son:
#              print("Siz yutingiz")
#              break
#         else:
#             print("Kampyuter yuti")
#     except ValueError:
#         print("100 dan kichkina bo'lish kerak")




